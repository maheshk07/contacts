export interface Contact{
    firstName: any;
    lastName: any;
    phoneNumber: any;
    email:any;
    gender:any;
    location:any;
    imgURL: any;
    imageBinaryData:any;
}